export const environment = {
  production: true,
  baseURL: 'https://localhost:44353/api',
  windServiceBaseURL: 'https://api.openweathermap.org/data/2.5/weather?q=Durban,ZA&APPID=c42c272142ab700fab7705a3451088e6',
};
